from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.chains import RetrievalQA
import os
pdf_path = os.path.abspath("./docs/the_history_of_ship.pdf")
print(f"加载路径：{pdf_path}")
print("文件是否存在？", os.path.exists(pdf_path))

try:
    loader = PyPDFLoader(pdf_path)
    documents = loader.load()
    print(f"文档加载成功，共 {len(documents)} 块")
except Exception as e:
    print("❌ 加载失败：", e)
